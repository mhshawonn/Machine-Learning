import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import os

os.makedirs("data", exist_ok=True)

def generate_data():
    
    np.random.seed(42)

    # Generate x values from 1 to 100
    x = np.arange(1, 101).reshape(-1, 1)

    # Generate Gaussian noise
    noise = np.random.normal(0, 1, size=x.shape)

    # Linear equation: y = 3 + 5x + noise
    y = 3 + 5 * x + noise

    # Create DataFrame
    df = pd.DataFrame(np.hstack((x, y)), columns=["x", "y"])

    # Save to CSV for future use
    df.to_csv("data/lab01_data.csv", index=False)

def load_data():
    return pd.read_csv("data/lab01_data.csv")

def process_data():
    # Load the data
    df = load_data()

    # Split the dataset into training and validation sets (80%-20%)
    train_df, val_df = train_test_split(df, test_size=0.2, random_state=42)

    # Add a dummy feature (x0) with all 1’s (for bias term)
    train_X = np.c_[np.ones(train_df.shape[0]), train_df["x"].values.reshape(-1, 1)]
    val_X = np.c_[np.ones(val_df.shape[0]), val_df["x"].values.reshape(-1, 1)]

    # Target values
    train_y = train_df["y"].values.reshape(-1, 1)
    val_y = val_df["y"].values.reshape(-1, 1)

    return train_X, train_y, val_X, val_y, df
